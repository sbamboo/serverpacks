import json

keys = ['chainmail_$allium', 'chainmail_$azalea', 'chainmail_$azure_bluet', 'chainmail_$blue_orchid', 'chainmail_$buttercup', 'chainmail_$cornflower', 'chainmail_$dandelion', 'chainmail_$lilac', 'chainmail_$lily_of_the_valley', 'chainmail_$orange_tulip', 'chainmail_$oxeye_daisy', 'chainmail_$peony', 'chainmail_$pink_daisy', 'chainmail_$pink_tulip', 'chainmail_$poppy', 'chainmail_$red_tulip', 'chainmail_$rose_bush', 'chainmail_$sunflower', 'chainmail_$white_tulip', 'chainmail_$wither_rose', 'diamond_$allium', 'diamond_$azalea', 'diamond_$azure_bluet', 'diamond_$blue_orchid', 'diamond_$buttercup', 'diamond_$cornflower', 'diamond_$dandelion', 'diamond_$lilac', 'diamond_$lily_of_the_valley', 'diamond_$orange_tulip', 'diamond_$oxeye_daisy', 'diamond_$peony', 'diamond_$pink_daisy', 'diamond_$pink_tulip', 'diamond_$poppy', 'diamond_$red_tulip', 'diamond_$rose_bush', 'diamond_$sunflower', 'diamond_$white_tulip', 'diamond_$wither_rose', 'gold_$allium', 'gold_$azalea', 'gold_$azure_bluet', 'gold_$blue_orchid', 'gold_$buttercup', 'gold_$cornflower', 'gold_$dandelion', 'gold_$lilac', 'gold_$lily_of_the_valley', 'gold_$orange_tulip', 'gold_$oxeye_daisy', 'gold_$peony', 'gold_$pink_daisy', 'gold_$pink_tulip', 'gold_$poppy', 'gold_$red_tulip', 'gold_$rose_bush', 'gold_$sunflower', 'gold_$white_tulip', 'gold_$wither_rose', 'iron_$allium', 'iron_$azalea', 'iron_$azure_bluet', 'iron_$blue_orchid', 'iron_$buttercup', 'iron_$cornflower', 'iron_$dandelion', 'iron_$lilac', 'iron_$lily_of_the_valley', 'iron_$orange_tulip', 'iron_$oxeye_daisy', 'iron_$peony', 'iron_$pink_daisy', 'iron_$pink_tulip', 'iron_$poppy', 'iron_$red_tulip', 'iron_$rose_bush', 'iron_$sunflower', 'iron_$white_tulip', 'iron_$wither_rose', 'leather_$allium', 'leather_$azalea', 'leather_$azure_bluet', 'leather_$blue_orchid', 'leather_$buttercup', 'leather_$cornflower', 'leather_$dandelion', 'leather_$lilac', 'leather_$lily_of_the_valley', 'leather_$orange_tulip', 'leather_$oxeye_daisy', 'leather_$peony', 'leather_$pink_daisy', 'leather_$pink_tulip', 'leather_$poppy', 'leather_$red_tulip', 'leather_$rose_bush', 'leather_$sunflower', 'leather_$white_tulip', 'leather_$wither_rose', 'netherite_$allium', 'netherite_$azalea', 'netherite_$azure_bluet', 'netherite_$blue_orchid', 'netherite_$buttercup', 'netherite_$cornflower', 'netherite_$dandelion', 'netherite_$lilac', 'netherite_$lily_of_the_valley', 'netherite_$orange_tulip', 'netherite_$oxeye_daisy', 'netherite_$peony', 'netherite_$pink_daisy', 'netherite_$pink_tulip', 'netherite_$poppy', 'netherite_$red_tulip', 'netherite_$rose_bush', 'netherite_$sunflower', 'netherite_$white_tulip', 'netherite_$wither_rose', 'turtle_$allium', 'turtle_$azalea', 'turtle_$azure_bluet', 'turtle_$blue_orchid', 'turtle_$buttercup', 'turtle_$cornflower', 'turtle_$dandelion', 'turtle_$lilac', 'turtle_$lily_of_the_valley', 'turtle_$orange_tulip', 'turtle_$oxeye_daisy', 'turtle_$peony', 'turtle_$pink_daisy', 'turtle_$pink_tulip', 'turtle_$poppy', 'turtle_$red_tulip', 'turtle_$rose_bush', 'turtle_$sunflower', 'turtle_$white_tulip', 'turtle_$wither_rose']  # your full list here

output = {}
for key in keys:
    entry_name = f"flowercrown_{key.replace("$","")}"
    output[entry_name] = {
        "humanoid": [[
            f"assets/flower_crowns/{key.replace("$","helmet_")}_crown/texture.png",
            "none",
            {
                "helmet": f"assets/flower_crowns/{key.replace("$","helmet_")}_crown/texture_item.png"
            }
        ]]
    }

with open("flowercrowns_output.json", "w") as f:
    json.dump(output, f, indent=4)
