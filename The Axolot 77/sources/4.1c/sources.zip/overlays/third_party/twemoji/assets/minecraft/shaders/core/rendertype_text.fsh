#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl> // This imports ColorModulator via the uniform block

uniform sampler2D Sampler0;

// REMOVE THIS LINE:
// uniform vec4 ColorModulator; // <-- CONFLICTS WITH DynamicTransforms uniform block

uniform vec2 ScreenSize; // Keep ScreenSize, it's not in any of the new uniform blocks you've shown.

in float sphericalVertexDistance;
in float cylindricalVertexDistance;

in vec4 vertexColor;
in vec2 texCoord0;
in vec3 pos;
in vec4 lightMapColor;
in vec4 screenPos;

out vec4 fragColor;

void main() {
    // ColorModulator is now implicitly available from the DynamicTransforms uniform block
    vec4 color = texture(Sampler0, texCoord0) * ColorModulator;

    if (color.a == 1.0 || color.a == 0.0) {
        color *= vertexColor;
    } else if (pos.z == 50.0 || pos.z == 0.0 || pos.z == 350.0 || pos.z == 2650.0 || pos.z == 0.1 || pos.z == 2600.1 || pos.z == 400.0 || pos.z == 2400.0 || pos.z == 2200.0 || pos.z == 1000.0) {
        if (pos.z == 0.0 && screenPos.y > (ScreenSize.y / 5.0) || pos.z != 0.0) {
            color *= vec4(62.0 / 252.0, 62.0 / 252.0, 62.0 / 252.0, vertexColor.a);
        }
    } else {
        color.a *= vertexColor.a;
        color *= lightMapColor;
    }

    if (color.a < 0.1) {
        discard;
    }

    if (pos.z == 54.0 && color.a < 1.0) {
        float light = (lightMapColor.r + lightMapColor.g + lightMapColor.b) / 3.0;
        color.a = mix(color.a, light, abs(1.0 - color.a));
    }

    // Fog uniforms (FogEnvironmentalStart, FogEnvironmentalEnd, etc.) are available
    // from the Fog uniform block imported via minecraft:fog.glsl
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}