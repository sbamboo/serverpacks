#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl> // This imports ModelViewMat and ColorModulator
#moj_import <minecraft:projection.glsl> // This imports ProjMat

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

// REMOVE THESE LINES IF PRESENT (but your last VSH didn't have them explicitly)
// uniform mat4 ModelViewMat; // Conflicts with DynamicTransforms uniform block
// uniform mat4 ProjMat;      // Conflicts with Projection uniform block

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec3 pos;
out vec4 lightMapColor;
out vec4 screenPos;

void main() {
    // ModelViewMat and ProjMat are now implicitly available from their respective uniform blocks
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    pos = Position;
    screenPos = ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
    vertexColor = Color;

    texCoord0 = UV0;
}