! THIS PACK IS FOR PRIVATE/PERSONAL USE ONLY !

This pack contains merges with other packs see: https://sbamboo.github.io/websa?id=01

Author for main/base pack: Simon Kalmi Claesson

The authors of the merged packs remains in full ownership of their packs/assets and remains with the right to contact me to remove the pack from the merge.

Custom Hats:
  harrelama           : "HarreLLama"
  axelot              : "Axolot77"
  chamelont           : "Chamelont"
  chipmunk            : "chipmunkZ00Z"

MERGED DATA:
ShieldCorrections:
  /textures/*
  /assets/minecraft/textures/entity/shield/*
  /assets/minecraft/textures/entity/shield_base/*
  /assets/minecraft/textures/entity/shield_base.png
  /assets/minecraft/models/item/shield.json
  /assets/minecraft/models/item/shield_blocking.json

Hats++:
  /assets/minecraft/textures/misc/pumpkinblur.png
  /assets/minecraft/optifine/emissive.properties
  /assets/minecraft/optifine/cit/hats_plus_plus/*


Hats++ Included Hats:
  allay               : "allay"
  arrow               : "arrow"
  axolotl_head        : "axolotl head"
  bucket              : "bucket head"
  cool_glasses        : "cool glasses"
  copper_golem        : "copper golem"
  floating_crown      : "floating crown"
  flower              : "flower"
  flower_crown        : "flower crown"
  fox                 : "fox"
  glow_squid          : "glow squid"
  halo                : "halo"
  hd_eyes             : "hd eyes"
  hedgehog            : "hedgehog"
  lightbulb           : "lightbulb"
  little_creeper      : "little creeper"
  little_enderman     : "little enderman"
  little_zombie       : "little zombie"
  minecart            : "minecart"
  moon                : "moon"
  moon_orbit          : "moon orbit"
  mushroom            : "mushroom man"
  on_fire             : "on fire"
  pickaxe             : "pickaxe"
  sun                 : "sun"
  sus                 : "sus"
  traffic_cone        : "traffic cone"
  water_spill         : "water spill"
  wolf                : "wolf"
 
Hats++ Included Hats (NameChanged)
  celestial_witch_hat : "celestial witch hat" (OGNAME: "Celestial Witch Hat")
  crown               : "3D crown"            (OGNAME: "crown")
  headphones          : "headphones"          (OGNAME: "headphones1")
  villager_nose       : "villager nose"       (OGNAME: "villager Nose")

