! THIS PACK IS FOR PRIVATE/PERSONAL USE ONLY !

This pack contains merges with other packs see: https://sbamboo.github.io/websa?id=02

Author for main/base pack: Simon Kalmi Claesson

The authors of the merged packs remains in full ownership of their packs/assets and remains with the right to contact me to remove the pack from the merge.

Custom Hats:
  harrelama           : "HarreLLama"
  axelot              : "Axolot77"
  chamelont           : "Chamelont"
  chipmunk            : "chipmunkZ00Z"
  bird                : "Bird Gang"
  bird_flying         : "Bird Flying"

MERGED DATA:
ShieldCorrections:
  /textures/*
  /assets/minecraft/textures/entity/shield/*
  /assets/minecraft/textures/entity/shield_base/*
  /assets/minecraft/textures/entity/shield_base.png
  /assets/minecraft/models/item/shield.json
  /assets/minecraft/models/item/shield_blocking.json

Hats++:
  /assets/minecraft/textures/misc/pumpkinblur.png
  /assets/minecraft/optifine/emissive.properties
  /assets/minecraft/optifine/cit/hats_plus_plus/*
  
Hoshi's:
  /assets/minecraft/optifine/cit/hoshis/*
  
JesterHats:
  /assets/minecraft/optifine/cit/jesterhats/*
  
SteampunkGoogles:
  /assets/minecraft/optifine/cit/steampunk_goggles/*
  
VillagerHats:
  /assets/minecraft/optifine/cit/villagerhats/*


Hats++ Included Hats:
  allay               : "allay"
  arrow               : "arrow"
  axolotl_head        : "axolotl head"
  bucket              : "bucket head"
  cool_glasses        : "cool glasses"
  copper_golem        : "copper golem"
  floating_crown      : "floating crown"
  flower              : "flower"
  flower_crown        : "flower crown"
  fox                 : "fox"
  glow_squid          : "glow squid"
  halo                : "halo"
  hd_eyes             : "hd eyes"
  hedgehog            : "hedgehog"
  lightbulb           : "lightbulb"
  little_creeper      : "little creeper"
  little_enderman     : "little enderman"
  little_zombie       : "little zombie"
  minecart            : "minecart"
  moon                : "moon"
  moon_orbit          : "moon orbit"
  mushroom            : "mushroom man"
  on_fire             : "on fire"
  pickaxe             : "pickaxe"
  sun                 : "sun"
  sus                 : "sus"
  traffic_cone        : "traffic cone"
  water_spill         : "water spill"
  wolf                : "wolf"
 
Hats++ Included Hats (NameChanged)
  celestial_witch_hat : "celestial witch hat" (OGNAME: "Celestial Witch Hat")
  crown               : "3D crown"            (OGNAME: "crown")
  headphones          : "headphones"          (OGNAME: "headphones1")
  villager_nose       : "villager nose"       (OGNAME: "villager Nose")

Hoshi's:
  ghost_buddy         : "ghost shoulder buddy"
  ducky_hat           : "ducky hat"
  unicorn_hat         : "unicorn hat"
  little_devil        : "little devil"
JesterHats (renamed some):
  jester_hat_black    : "Black Jester Hat"  (OGNAME: "Black Jaster Hat")
  jester_hat_yellow   : "Yellow Jester Hat" (OGNAME: "Yellow Jaster Hat")
  jester_hat_pink     : "Pink Jester Hat"   (OGNAME: "Pink Jester Hat")
SteampunkGoggles:
  steampunk_goggles   : "Steampunk Goggles"
VillagerHats (renamed):
  armorer             : "armorer"     (OGNAME: "goggles")
  butcher             : "butcher"     (OGNAME: "headband")
  farmer              : "farmer"      (OGNAME: "farmer_hat")
  fisherman           : "fisherman"   (OGNAME: "fisherman_hat")
  fletcher            : "fletcher"    (OGNAME: "fletcher_hat")
  librarian           : "librarian"   (OGNAME: "book")
  shepherd            : "shepherd"    (OGNAME: "shepherd_hat")
  weaponsmith         : "weaponsmith" (OGNAME: "eyepatch")